# MAILTRACE 2.0 - AI-Powered Email Forensics & Threat Intelligence Platform

> **Phase 0 Monorepo Foundation**: This repository represents the modular architecture foundation for MAILTRACE 2.0. Phase 0 implements the clean directory structure, FastAPI backend, React+TS SOC dashboard, Chrome Manifest V3 extension popup, PostgreSQL Docker Compose setup, shared types, and automated verification suites. No mock security threat data or fake detection scores are generated in this phase.

---

## 🚀 Overview

**MAILTRACE 2.0** is an advanced AI-powered email forensics and threat-intelligence platform designed for Security Operations Center (SOC) analysts and cybersecurity investigators. It analyzes email headers, body content, SPF/DKIM/DMARC authentication records, infrastructure IOCs, and neural sequence patterns to identify phishing, BEC (Business Email Compromise), spoofing, and social engineering attacks.

---

## 🏗️ Monorepo Folder Structure

```
MAILTRACE/
├── apps/
│   ├── extension/             # Chrome/Edge Manifest V3 Popup (React + TS + Vite + Tailwind)
│   └── dashboard/             # SOC Forensics Dashboard Shell (React + TS + Vite + Tailwind + Framer Motion)
├── services/
│   └── api/                   # FastAPI Backend Service (Python + Pydantic + Uvicorn)
├── ai/
│   └── threat-engine/         # RoBERTa Threat Classifier Architecture Specs & Abstract Interfaces
├── database/
│   ├── migrations/            # Database Alembic Migration Scripts Placeholder
│   └── seeds/                 # Database Seed Files Placeholder
├── shared/
│   └── types/                 # Shared TypeScript API contracts
├── docs/                      # Architectural specs & security guidelines
├── tests/                     # Integration and monorepo verification tests
├── docker/                    # Container configuration files
├── .env.example               # Root environment variables template
├── .gitignore                 # Git ignore rules
├── README.md                  # Developer documentation
└── docker-compose.yml         # PostgreSQL infrastructure config
```

---

## 🛠️ Technology Stack

| Layer | Technologies |
| :--- | :--- |
| **Browser Extension** | Manifest V3, React, TypeScript, Vite, Tailwind CSS |
| **SOC Dashboard** | React, TypeScript, Vite, Tailwind CSS, React Router, Framer Motion |
| **Backend API** | Python 3.10+, FastAPI, Pydantic v2, Uvicorn, Pytest |
| **AI Threat Engine** | Python, PyTorch, Hugging Face Transformers (RoBERTa Architecture) |
| **Database** | PostgreSQL 16, SQLAlchemy, Alembic |
| **Infrastructure** | Docker, Docker Compose |

---

## 📋 Prerequisites

* **Python**: 3.10 or higher
* **Node.js**: v18.0.0 or higher
* **npm**: v9.0.0 or higher
* **Docker & Docker Desktop** (for PostgreSQL database)

---

## ⚙️ Development Setup (Windows PowerShell)

### 1. Environment Setup

Copy `.env.example` to create your local `.env` file:

```powershell
Copy-Item .env.example .env
```

---

### 2. Backend Setup (`services/api`)

Navigate to the API service directory and start the server:

```powershell
cd services/api
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --reload
```

* Backend API will run on `http://localhost:8000`
* Health Check Endpoint: `http://localhost:8000/api/health`

---

### 3. SOC Dashboard Setup (`apps/dashboard`)

Open a new PowerShell terminal, navigate to the dashboard app:

```powershell
cd apps/dashboard
npm install
npm run dev
```

* Dashboard will run on `http://localhost:5173`
* Uses `import.meta.env.VITE_API_BASE_URL` (configured in `apps/dashboard/.env`) to query the backend API health status.

---

### 4. Extension Setup (`apps/extension`)

Open a new PowerShell terminal, navigate to the extension app:

```powershell
cd apps/extension
npm install
npm run build
```

* Built Manifest V3 extension files will be emitted to `apps/extension/dist/`.
* To load into Chrome/Edge: Go to `chrome://extensions/` -> Enable **Developer mode** -> Click **Load unpacked** -> Select the `apps/extension/dist/` folder.

---

### 5. PostgreSQL Setup (Docker Compose)

Start the database container using Docker Compose:

```powershell
docker compose up -d
```

---

## 🧪 Testing & Verification

Run backend unit tests:

```powershell
cd services/api
.\.venv\Scripts\Activate.ps1
pytest
```

---

## 🔒 Security Principles

1. **No Hardcoded Secrets**: Secrets and API keys remain strictly in server-side `.env` files.
2. **Untrusted Input Handling**: Email content is sanitized; `eval()` and unsafe HTML dynamic injection are forbidden.
3. **Execution Safety**: Attachments are never automatically executed; links are never automatically followed.
4. **CORS Control**: Dynamic CORS configuration enforcing explicitly trusted origins.
5. **Decoupled API URL**: Dashboard client reads backend base URL from `import.meta.env.VITE_API_BASE_URL`.

---

## 📍 Phase Roadmap

- [x] **Phase 0**: Monorepo Foundation, FastAPI Health Check, Dashboard Shell, Manifest V3 Extension Popup, Docker Setup.
- [ ] **Phase 1**: Header Parsing Engine & SPF/DKIM/DMARC Forensic Validator.
- [ ] **Phase 2**: RoBERTa ML Model Training & AI Threat Inference Pipeline.
- [ ] **Phase 3**: Chrome Extension Gmail/Outlook Payload Ingestion.
- [ ] **Phase 4**: VirusTotal & MaxMind GeoIP Intelligence Integration.
- [ ] **Phase 5**: Complete SOC Investigation Dashboard & PDF Evidence Report Export.
