# MAILTRACE AI Threat Engine Architecture

## Overview
The `ai/threat-engine` module houses the ML pipeline responsible for analyzing email content (headers, body text, metadata) to classify emails into risk categories: Phishing, BEC (Business Email Compromise), Spoofing, or Social Engineering.

## Planned Stack
* **Framework**: PyTorch
* **Transformers**: Hugging Face `transformers`
* **Base Model**: Fine-tuned RoBERTa (`roberta-base` / `roberta-large`) for sequence classification

## Phase 0 Status
This phase establishes the abstract model interface contracts (`model_interface.py`). Model weights, tokenization pipelines, and inference handlers will be integrated in subsequent phases following real training on benchmark security datasets. No mock scores or fake results are evaluated in Phase 0.
